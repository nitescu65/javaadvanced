package com.sda.marius.advanced.recapitulare;

public enum Gender {
   MALE,FEMALE
}
