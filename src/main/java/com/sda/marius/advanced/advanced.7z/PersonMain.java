package com.sda.marius.advanced;

import com.sda.marius.advanced.recapitulare.Gender;
import com.sda.marius.advanced.recapitulare.Person;

public class PersonMain {
    public static void main(String[] args) {
        Person person = new Person(22, "Didi", Gender.FEMALE);
        Person person2 = new Person();
        person2.setAge(22);
        person2.setName("Didi");
        person2.setGender(Gender.FEMALE);

        System.out.println("Person2 : " + person2);
        System.out.println("Person  : " + person);

        if (person.equals(person2)) {
            System.out.println("Are equal");
        } else {
            System.out.println("Not equal");
        }

    }
}
